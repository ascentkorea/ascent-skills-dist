# 검색 맥락 분석 · 실행 절차

현재 시점만 본다. 산출물은 **요약 + 마케팅 할 일 + 경로 맵**이고, 경로 분석은 사용자가
페이지에서 경로를 고른 뒤 복사한 요청문을 대화창에 붙여 넣으면 이 스킬이 수행한다.
수치는 `scripts/sc.py` 가 계산한다 — LLM 이 직접 쓰는 것은 5단계의 요약과 마케팅 할 일뿐이다.

모든 Bash 명령 최상단에서 SKILL.md 방식으로 `SKILL_DIR` 을 찾는다.

## 0단계 — 입력 확인 + 작업 폴더

**개인정보가 먼저다** · 사용자 메시지에 전화번호 · 이메일 · 신분증/카드/계좌번호 같은
개인정보가 있으면 여기서 멈추고 그 부분을 뺀 문장으로 다시 요청해 달라고 한다
(API 호출 0건 · SKILL.md 「user_query」 참조).

필요한 입력 · API 키 · 시드 · 국가(`gl`) · 경로 수(PATHS · 100 · 200 · 300 · 기본 300).
국가가 분명하지 않으면 **한 번만, 한 질문으로** 묻고 **경로 수도 그 질문에 함께** 묻는다
(예: "경로는 몇 개를 볼까요 — 100 · 200 · 300? 기본은 300입니다.").
경로 수만 빠졌고 국가가 분명하면 따로 묻지 말고 300 으로 진행한다.

비용을 짧게 알린다(경로 수 포함): "경로 <PATHS>개 · 경로에 나온 유니크 키워드 수에 따라
과금되며 보통 수천 크레딧 수준입니다 · 경로 분석은 키워드 1개당 10 크레딧".
**크레딧**이다(리마가 아니다). 고정값을 말하지 않는다 — 비용은 경로 수가 아니라 유니크
키워드 수로 정해져 시드마다 다르다(SKILL.md 「데이터 조회 비용」). 개별 호출을 나열하지 않는다.

```bash
SAFE=$(echo "<SEED>" | tr ' /\\:*?"<>|' '_')
WORKDIR="$PWD/tmp/reports/listeningmind-search-context-${SAFE}-$(date +%Y%m%d-%H%M%S)"; mkdir -p "$WORKDIR/serp"
```

API 키는 환경변수로 넘긴다 (명령줄 인자로 적으면 셸 히스토리에 남는다):

```bash
export LIMA_DAAS_API_KEY="<사용자가 채팅으로 준 키>"
```

## 1단계 — 경로 (path_finder × 1, 현재 시점)

0단계에서 정한 PATHS 만큼 받아 **요약·마케팅 분석·처음 맵에 전부 쓴다**(3단계 `--show <PATHS>`).
`limit` 에 PATHS 를 넣는다. **limit 이 다르면 서버가 주는 경로 묶음 자체가 달라진다**
(limit 100 ≠ limit 300 의 앞 100개). 다른 limit 으로 받은 응답을 잘라 쓰지 않는다.
페이지에서는 받아 둔 범위 안에서 100 / 200 / 300 으로 좁혀 볼 수 있다(추가 호출 없음).

```bash
cat > "$WORKDIR/path_body.json" <<'EOF'
{"keyword":"<SEED>","gl":"<MARKET>","time_point":"curr","limit":<PATHS>}
EOF
python3 "$SKILL_DIR/scripts/daas_call.py" path_finder \
  --body "$WORKDIR/path_body.json" --out "$WORKDIR/lm_path.json" \
  --intent journey_analysis --intent-note "시드를 지나는 검색 경로로 맥락을 읽는다"
```

## 2단계 — 검색량 (keyword_info × 1)

```bash
python3 "$SKILL_DIR/scripts/sc.py" kwparams --paths "$WORKDIR/lm_path.json" \
  --gl <MARKET> --out "$WORKDIR/kw_params.json"
python3 "$SKILL_DIR/scripts/daas_call.py" keyword_info \
  --body "$WORKDIR/kw_params.json" --out "$WORKDIR/lm_nodes.json" \
  --intent journey_analysis --intent-note "경로 위 키워드의 검색량"
```

## 3단계 — 계획

```bash
python3 "$SKILL_DIR/scripts/sc.py" plan --paths "$WORKDIR/lm_path.json" --nodes "$WORKDIR/lm_nodes.json" \
  --seed "<SEED>" --gl <MARKET> --lang <REPORT_LANGUAGE> --date <YYYY-MM-DD> --show <PATHS> --out "$WORKDIR/plan.json"
```

SERP 를 볼 키워드가 출력된다 (E1 = 시드, E2… = 시드 다음 주요 분기).
경로 수는 `--show` 기준이다(= PATHS · 기본 300).

> `--lang` 은 지금 `kr` 만 쓴다. 이 판은 한국 시장만 지원한다(SKILL.md 참조).

## 4단계 — SERP (serp × E 코드 수)

코드마다 `$WORKDIR/serp/serp_<코드>.json` 하나. **하나씩 차례로** 부른다 (병렬 금지).
같은 키워드를 이 대화에서 이미 받았으면 캐시가 적중하므로 그대로 둔다.

```bash
# E 코드마다 반복 · <KW> 는 plan.json 의 키워드
cat > "$WORKDIR/serp_body.json" <<'EOF'
{"keyword":"<KW>","gl":"<MARKET>","num":10}
EOF
python3 "$SKILL_DIR/scripts/daas_call.py" serp \
  --body "$WORKDIR/serp_body.json" --out "$WORKDIR/serp/serp_<코드>.json" \
  --intent journey_analysis --intent-note "경로 위 키워드의 검색 목적 근거"
```

```bash
python3 "$SKILL_DIR/scripts/sc.py" serp-trim --plan "$WORKDIR/plan.json" \
  --serp-dir "$WORKDIR/serp" --out "$WORKDIR/evidence.json"
python3 "$SKILL_DIR/scripts/sc.py" brief --plan "$WORKDIR/plan.json" \
  --evidence "$WORKDIR/evidence.json" --out "$WORKDIR/brief.md"
```

## 5단계 — 요약 + 마케팅 할 일 (LLM) → `marketing_raw.json`

brief.md 를 읽고 **짧게** 쓴다. 사용자는 많은 분량을 원하지 않는다.

- `summary`: 2~3문장. 지금 이 시드를 검색하는 사람들이 어디로 향하는지, 무엇을 비교·확인하는지.
- `actions`: 3~5개. 마케터가 바로 할 수 있는 것. 각 항목은
  `title`(한 줄), `why`(1~2문장 · 경로·SERP 근거. 리포트는 E 번호와 SERP 출처의 대응을 보여주지
  않으므로 `E2-AI` · `E3-1` 같은 번호를 쓰지 말고 말로 적는다 — 예: `"나이키 신발" AI 개요,
  "나이키" 자연 검색 3위(한경)`), `how`(1~2문장 · 콘텐츠 · SERP 노출 · 상품 페이지 · 광고
  키워드 · 가격 노출 등 구체적 실행), `keywords`(1~4개 · brief.md 에 나온 그대로).
- 원칙: brief.md 에 없는 사실·키워드를 지어내지 않는다. 수치를 단정하지 않는다(경로 수는
  표본이다). 근거가 약하면 "추정" 이라고 적는다. 출력 언어 = 리포트 언어 · 키워드는 원문 유지.

```json
{"summary": "…", "actions": [{"title": "…", "why": "… (\"나이키\" 자연 검색 3위(한경))", "how": "…", "keywords": ["…"]}]}
```

## 6단계 — 렌더 + 검사

**`--host` 는 항상 `chatgpt`** 다 (SKILL.md 「HOST 는 항상 chatgpt 로 렌더한다」).
이 판은 페이지가 스스로 LLM 을 부르지 않고 요청문을 복사해 준다.

```bash
python3 "$SKILL_DIR/scripts/sc.py" render --plan "$WORKDIR/plan.json" --evidence "$WORKDIR/evidence.json" \
  --analysis "$WORKDIR/marketing_raw.json" --lang <REPORT_LANGUAGE> --host chatgpt --out "$WORKDIR/report.html"
python3 "$SKILL_DIR/scripts/check_report.py" "$WORKDIR/report.html"
```

✗ 가 하나라도 있으면 넘기지 않는다. `⚠ 경로에 없는 키워드를 뺐습니다` 가 뜨면 그 항목의
`keywords` 를 고친다.

## 7단계 — 전달

`report.html` 을 파일로 건넨다. 별도의 게시(publish) 단계는 없다.

페이지 사용법을 함께 설명한다 · 맵에서 키워드를 눌러 경로를 고르고 **「경로 분석 요청 복사」**
를 누르면 요청문이 복사된다. 그것을 **이 대화창에 붙여 넣으면** 경로 위 키워드의 SERP 를
조회해 해석한다. 아래 「질문·경로 분석」 입력도 같은 방식으로 요청문을 복사해 준다.

붙여 넣은 요청을 받으면 · 4단계와 같은 방식으로 경로 위 키워드의 `serp` 를 하나씩 받아
(이미 받은 키워드는 캐시가 적중한다) 그 근거로 검색 목적을 해석해 답한다.

## 8단계 — 사용자에게 알리기 (리포트 언어)

요약 한두 줄과 마케팅 할 일 제목만 전하고, "맵에서 키워드를 눌러 경로를 고른 뒤 「경로 분석
요청 복사」 를 눌러 여기에 붙여 넣으면 분석한다" 를 설명한다. 경로 분석은 경로 위
키워드 1개당 10 크레딧이 든다는 것도 함께 알린다.

이번 리포트 비용은 응답들의 `cost_detail.total_cost` 합으로 전한다.
