#!/usr/bin/env python3
"""daas_call.py · DaaS API 호출 · 세션 캐시 · 로깅을 한자리에서 처리한다.

리포트 계열은 문서가 curl 을 직접 지시해서, 캐시 조회나 크레딧 기록을 끼워 넣을
자리가 없었다. 이 스크립트가 curl 을 대신하면서 아래를 함께 처리한다.

  1. 세션 캐시 조회 — 같은 대화창에서 같은 (endpoint + body) 면 API 를 부르지 않는다
  2. user_query 첨부 — 문서가 따로 지시하던 절차
  3. tool_call 발행 — 응답 봉투의 cost_detail.total_cost 를 직접 읽어 기록

3번이 특히 중요하다. 지금까지는 LLM 이 봉투를 눈으로 읽어 --used-credits-delta 에
옮겨 적어야 했고, 그래서 문서마다 "호출 수로 대충 계산 금지" 같은 경고가 붙어 있었다.
여기서 읽으면 그 경고가 필요 없다.

캐시는 playbook(api/client.py) 과 같은 저장소·같은 키 규칙을 쓴다:
  ~/.lima-agents/rest-cache/<session_id>.json · key = sha256(endpoint + 정렬된 body)
스킬이 달라도 같은 세션·같은 파라미터면 적중한다. 그래서 pathfinder-report 를 돌린 뒤
total-report 를 돌리면 두 번째 path_finder 호출이 사라진다.

사용:
  python3 scripts/daas_call.py path_finder \
      --body body.json --out "{WORKDIR}/lm_path.json" \
      --intent journey_analysis --intent-note "전통주 검색 여정"

  # body 를 파일 대신 인라인으로
  python3 scripts/daas_call.py keyword_info --body-json '{"keywords":[...],...}' --out out.json

환경 변수:
  LIMA_DAAS_API_KEY  API 키 (또는 --api-key · ~/.lima-agents/api-key)
  LIMA_DAAS_REFRESH=1  이 세션에서 캐시를 무시하고 강제 재호출
  LIMA_DAAS_BASE     기본 https://listeningmind-data-api.ascentlab.io

성공하면 0 · 실패하면 1 을 반환하고 stderr 에 이유를 남긴다.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_DIR))

from api import logging as lima_log  # noqa: E402

DEFAULT_BASE = "https://listeningmind-data-api.ascentlab.io"
_REST_CACHE_DIR = Path.home() / ".lima-agents" / "rest-cache"
_TIMEOUT = 180
_RETRY_CODES = (429, 500, 502, 503, 504)

# endpoint → bare 도구 이름 (_contracts.md §1 매핑)
_TOOL_BY_PREFIX = (
    ("intent_finder", "intent_finder"),
    ("cluster_finder", "cluster_finder"),
    ("path_finder", "path_finder"),
    ("keyword_info", "keyword_info"),
)


def _endpoint_to_tool(endpoint: str) -> str:
    e = endpoint.strip("/").lower()
    for prefix, tool in _TOOL_BY_PREFIX:
        if e.startswith(prefix):
            return tool
    return e or "unknown"


# ── 캐시 ──────────────────────────────────────────────────────────────

def _cache_path(session_id: str) -> Path:
    return _REST_CACHE_DIR / f"{session_id}.json"


def _cache_key(endpoint: str, body: dict) -> str:
    """(endpoint + 정렬된 body) 해시 · 파라미터 하나만 달라도 다른 키.

    user_query 는 넣지 않는다 — 질의 문구가 달라져도 같은 데이터를 가리키므로,
    넣으면 캐시가 무력화되고 크레딧만 더 나간다.
    """
    canonical = json.dumps({"endpoint": endpoint, "body": body},
                           ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _cache_read(session_id: str, key: str) -> dict | None:
    p = _cache_path(session_id)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8")).get(key)
    except (OSError, json.JSONDecodeError):
        return None


def _cache_write(session_id: str, key: str, resp: dict) -> None:
    p = _cache_path(session_id)
    try:
        _REST_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        index = {}
        if p.exists():
            try:
                index = json.loads(p.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                index = {}
        index[key] = resp
        p.write_text(json.dumps(index, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass


def _refresh_enabled() -> bool:
    return os.getenv("LIMA_DAAS_REFRESH", "").strip().lower() in ("1", "true", "yes")


# ── API 키 ────────────────────────────────────────────────────────────

def _resolve_api_key(cli_key: str | None) -> str | None:
    if cli_key:
        return cli_key.strip()
    for env in ("LIMA_DAAS_API_KEY", "LM_API_KEY"):
        v = os.getenv(env)
        if v:
            return v.strip()
    f = Path.home() / ".lima-agents" / "api-key"
    if f.exists():
        try:
            return f.read_text(encoding="utf-8").strip()
        except OSError:
            pass
    return None


# ── 호출 ──────────────────────────────────────────────────────────────

def _post(url: str, api_key: str, send_body: dict, retries: int = 2) -> dict:
    data = json.dumps(send_body, ensure_ascii=False).encode("utf-8")
    headers = {"Content-Type": "application/json", "LM-API-KEY": api_key}
    last: Exception | None = None
    for attempt in range(retries + 1):
        try:
            req = urllib.request.Request(url, data=data, headers=headers)
            with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            if e.code in _RETRY_CODES and attempt < retries:
                time.sleep(2 ** attempt)
                last = e
                continue
            raise
        except Exception as e:  # noqa: BLE001
            last = e
            if attempt < retries:
                time.sleep(2 ** attempt)
                continue
            raise
    if last:
        raise last
    raise RuntimeError("unexpected retry loop exit")


def main() -> int:
    p = argparse.ArgumentParser(description="DaaS API 호출 · 세션 캐시 · tool_call 자동 발행")
    p.add_argument("endpoint", help="path_finder · cluster_finder · intent_finder/keyword_list · keyword_info")
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--body", help="요청 본문 JSON 파일 경로")
    src.add_argument("--body-json", help="요청 본문 JSON 문자열")
    p.add_argument("--out", required=True, help="응답을 저장할 파일 경로")
    p.add_argument("--api-key", default=None,
                   help="미지정 시 $LIMA_DAAS_API_KEY · ~/.lima-agents/api-key 순으로 찾는다")
    p.add_argument("--base", default=os.getenv("LIMA_DAAS_BASE", DEFAULT_BASE))
    p.add_argument("--intent", default=None,
                   choices=["market_scan", "brand_diagnosis", "competitive_comparison",
                            "perception_mapping", "journey_analysis", "query_expansion", "other"],
                   help="요청 성격 분류 (SKILL.md 목록)")
    p.add_argument("--intent-note", default=None, help="분류 근거·부연 한 줄")
    p.add_argument("--no-cache", action="store_true", help="이 호출만 캐시를 쓰지 않는다")
    args = p.parse_args()

    # 요청 본문
    try:
        raw = Path(args.body).read_text(encoding="utf-8") if args.body else args.body_json
        body = json.loads(raw)
        if not isinstance(body, dict):
            raise ValueError("본문이 JSON 객체가 아닙니다")
    except (OSError, json.JSONDecodeError, ValueError) as e:
        print(f"❌ 요청 본문을 읽지 못했습니다 · {e}", file=sys.stderr)
        return 1

    api_key = _resolve_api_key(args.api_key)
    if not api_key:
        print("❌ API 키가 없습니다 · --api-key 또는 $LIMA_DAAS_API_KEY 또는 "
              "~/.lima-agents/api-key 를 설정하세요", file=sys.stderr)
        return 1

    tool = _endpoint_to_tool(args.endpoint)
    out_path = Path(args.out)

    # 세션 · 캐시 키
    sid = None
    key = None
    try:
        sid = lima_log.current_session_id() or lima_log.resolve_conversation_id()
        key = _cache_key(args.endpoint, body)
    except Exception:  # noqa: BLE001 — 캐시는 부가 기능
        sid = None

    use_cache = bool(sid and key) and not args.no_cache and not _refresh_enabled()
    if use_cache:
        hit = _cache_read(sid, key)
        if hit is not None:
            try:
                out_path.parent.mkdir(parents=True, exist_ok=True)
                out_path.write_text(json.dumps(hit, ensure_ascii=False), encoding="utf-8")
            except OSError as e:
                print(f"❌ 응답을 저장하지 못했습니다 · {e}", file=sys.stderr)
                return 1
            try:
                lima_log.tool_call(
                    tool, request_body=body,
                    used_credits_cumulative=0, used_credits_delta=0,  # 재소모 없음
                    result="OK", cached=True, source="rest",
                    intent=args.intent, intent_note=args.intent_note,
                )
            except Exception:  # noqa: BLE001 — 로깅 실패가 흐름을 막지 않는다
                pass
            print(f"✓ {tool} · 캐시 재사용 · 크레딧 소모 없음 → {out_path}")
            return 0

    # user_query 첨부 (질의-검색 연관성 분석용 · 캐시 키에는 넣지 않는다)
    send_body = body
    try:
        uq = lima_log.build_user_query(sid) if sid else None
        if uq:
            send_body = {**body, "user_query": uq}
    except Exception:  # noqa: BLE001
        send_body = body

    url = f"{args.base.rstrip('/')}/{args.endpoint.lstrip('/')}"
    try:
        parsed = _post(url, api_key, send_body)
    except urllib.error.HTTPError as e:
        try:
            detail = e.read()[:200].decode("utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            detail = ""
        print(f"❌ {tool} · HTTP {e.code} · {detail}", file=sys.stderr)
        try:
            lima_log.tool_call(tool, request_body=body, used_credits_cumulative=0,
                               used_credits_delta=None, result="ERROR", cached=False,
                               source="rest", intent_note=f"HTTP_{e.code}")
        except Exception:  # noqa: BLE001
            pass
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"❌ {tool} · {type(e).__name__}: {e}", file=sys.stderr)
        try:
            lima_log.tool_call(tool, request_body=body, used_credits_cumulative=0,
                               used_credits_delta=None, result="ERROR", cached=False,
                               source="rest", intent_note=f"ERROR: {type(e).__name__}")
        except Exception:  # noqa: BLE001
            pass
        return 1

    # 저장
    try:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(parsed, ensure_ascii=False), encoding="utf-8")
    except OSError as e:
        print(f"❌ 응답을 저장하지 못했습니다 · {e}", file=sys.stderr)
        return 1

    if use_cache:
        _cache_write(sid, key, parsed)

    # 봉투에서 크레딧을 직접 읽는다 (LLM 이 눈으로 옮겨 적던 값)
    cost_detail = parsed.get("cost_detail") or {}
    call_cost = int(cost_detail.get("total_cost", 0) or 0)
    cumulative = int(parsed.get("used_credits", 0) or 0)
    raw_result = str(parsed.get("result", "OK")).strip().upper()
    norm_result = "ERROR" if raw_result.startswith(("ERROR", "FAILED")) else "OK"

    try:
        lima_log.tool_call(
            tool, request_body=body,
            used_credits_cumulative=cumulative, used_credits_delta=call_cost,
            result=norm_result, cached=False, source="rest",
            intent=args.intent, intent_note=args.intent_note,
        )
    except Exception:  # noqa: BLE001
        pass

    if norm_result == "ERROR":
        print(f"⚠ {tool} · 서버가 실패를 반환했습니다 · {parsed.get('reason')}", file=sys.stderr)
        return 1

    print(f"✓ {tool} · {call_cost:,} crd → {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
